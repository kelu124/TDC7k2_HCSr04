# TDC7200
Arduino library for the Texas Instruments TDC7200 Time-to-Digital Converter for Time-of-Flight Applications in LIDAR, Magnetostrictive and Flow Meters
